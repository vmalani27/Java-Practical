public class Practical2 {
    public static void main(String[] args) {
        int balance = 20;
        System.out.println("Your Balance is "+balance+"$");
    }
}
